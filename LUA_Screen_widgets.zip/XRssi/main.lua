---------------------------------------------------------------------------
-- Lua widget to view RSSI signal during flight						     --
-- 				                                                         --
--                                                                       --
-- Author:  Xavier Torradas                                              --
-- Date:    2022-03-01                                                   --
-- Version: 1.0                                                          --
--                                                                       --
-- Free use                                                              --
--                                                                       --
-- 														                 --
--                                                                       --
-- This program is free software; you can redistribute it and/or modify  --
-- it under your responsability.										 --
-- 											                             --
--                                                                       --
-- This program is distributed in the hope that it will be useful        --
-- but WITHOUT ANY WARRANTY; without even the implied warranty of        --
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  		         --
-- 												                         --
-- On full screen with top bar active only you can see 3 columns that	 --
-- display the actual signal level at left side with sound advise for	 --
-- low level RSSI under 45db. Also in the middle display the hihg level  --
-- as RSSI+ and at right side column you can see the lowest RSSI level   --
-- as RSSI- that uder 45 level change from orange color to red color	 --
---------------------------------------------------------------------------


local options = {}

    local function create(zone, options)
    
    	local data = { zone=zone, options=options }
		   field = 0
		   cellId = -1
		   hrssi = 470
		   vrssi = 180
		   ivrssi = 0
		   fvrssi = 0 
		   mrssi = 0
		   numrssi = 1
		   totrssi = 0
		   menysrssi = 0
		  
	    --   logoxt = Bitmap.open("/WIDGETS/imatges/XTminilogo.png")	
	    return data

    end

    local function getTelemetryId(name)
       field = getFieldInfo(name)
       if field then
         return field.id
       else
         return -1
       end
    end

local function update(data, options)
	data.options = options
end

local function background(data)
		   mrssi = 0 
		   numrssi = 0
		   totrssi = 0
		   menysrssi = 0
end 

local function refresh(data)

 cellId = getTelemetryId("RSSI")

 if cellId > -1 then
 -- valor RSSI
	fvrssi = (100-getValue("RSSI"))*2.7; -- escala de pantalla
        lcd.drawFilledRectangle( 5, fvrssi, 110, 270, YELLOW);
	
	if getValue("RSSI") < 99 and getValue("RSSI") > 0 then
           numrssi = numrssi+1;
           totrssi = totrssi + getValue("RSSI");
           mrssi = totrssi/numrssi;	
	end
	
	
	if getValue("RSSI") <= 45 and getValue("RSSI")>0 then   
	   -- Valors d'advertencia
	   menysrssi = menysrssi + 1;
 	   lcd.drawText(10, 200, "RSSI:", LEFT + MIDSIZE + BLACK );
	   lcd.drawNumber( 80, 200, getValue("RSSI"), LEFT + MIDSIZE  + COLOR_THEME_WARNING );   	   
	   playTone(1000,300,0, PLAY_BACKGROUND);
	  else
	   -- Valors Normals
 	   lcd.drawText(10, 200 , "RSSI:", LEFT + MIDSIZE + BLACK );	   
	   lcd.drawNumber(80, 200, getValue("RSSI"), LEFT + MIDSIZE + BLUE );
	end
	-- Valors Maxims i Minims
	
	lcd.drawFilledRectangle( 180,(100-getValue("RSSI+"))*2.7, 110, 270, WHITE);	
	lcd.drawText(185, 200, "Rssi+: ", LEFT + MIDSIZE + BLACK );
	lcd.drawNumber(255, 200, getValue("RSSI+") , LEFT + MIDSIZE + BLACK );	

    lcd.drawFilledRectangle( 365, (100-getValue("RSSI-"))*2.7, 110, 270, ORANGE);	
	lcd.drawText(370, 200, "Rssi-: ", LEFT + MIDSIZE + BLACK );
	lcd.drawNumber(440, 200, getValue("RSSI-") , LEFT + MIDSIZE + WHITE );

	
	if getValue("RSSI-") <= 45 then  
	   lcd.drawFilledRectangle( 365, (100-getValue("RSSI-"))*2.7, 110, 270, RED);
       lcd.drawText(370, 200, "Rssi-: ", LEFT + MIDSIZE + BLACK );
	   lcd.drawNumber(440, 200, getValue("RSSI-") , LEFT + MIDSIZE + BLINK + WHITE );
        end
	
	--lcd.drawText(10, 160, "Tot:", LEFT + 0 + BLACK );
	--lcd.drawNumber( 60, 160, numrssi, LEFT + 0 + BLACK ); 
	--lcd.drawText(10, 175, "Sum:", LEFT + 0 + BLACK );
	--lcd.drawNumber( 50, 175, totrssi, LEFT + 0 + BLACK ); 
	--lcd.drawText(370, 175, "QTY:", LEFT + MIDSIZE + BLACK );
	--lcd.drawNumber( 430, 175, menysrssi, LEFT + MIDSIZE  + WHITE ); 	

	--lcd.drawText(185, 175, "Mitja:", LEFT + MIDSIZE + BLACK );
        --lcd.drawNumber(255, 175, mrssi, LEFT + MIDSIZE + BLUE );

	ivrssi = fvrssi;
	
 end	
		
	--lcd.drawBitmap(logoxt,420,50);
	

end


return { name="RSSI", options=options, create=create, update=update, refresh=refresh, background=background }
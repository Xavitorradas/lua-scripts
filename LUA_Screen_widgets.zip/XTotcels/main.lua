--------------------------------------------------------------------------
-- Lua widget to view RSSI signal during flight						     --
-- 				                                                         --
--                                                                       --
-- Author:  Xavier Torradas                                              --
-- Date:    2022-03-01                                                   --
-- Version: 1.0                                                          --
--                                                                       --
-- Free use                                                              --
--                                                                       --
-- 														                 --
--                                                                       --
-- This program is free software; you can redistribute it and/or modify  --
-- it under your responsability.										 --
-- 											                             --
--                                                                       --
-- This program is distributed in the hope that it will be useful        --
-- but WITHOUT ANY WARRANTY; without even the implied warranty of        --
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  		         --
-- 												                         --
-- 												                         --
-- The call to getValue() returns a table with the current voltage of    -- 
-- of the cells it is monitoring by frsky lipo sensor.					 --
-- This example demonstrates getting Lipo cell voltage from a sensor  	 --
-- with the default name of 'Cels'										 --
-- At left side you can see a column with maxium of 6 cells values		 --
-- In the midel in white you can see the total Cells voltatge and under  --
-- it the % of voltage calculated at (totcel-(i*3.6))/(celdes-(i*3.6)    --
-- The left side cells displayed must have the name of Cel1 to Cel6 to   --
-- read by lua widget													 --
---------------------------------------------------------------------------
local options = {}

local function create(zone, options, cellResult, cellValue)
		local data = { zone=zone, options=options }
        totcel = 0
		llarg = 70
		lPos = 0
		celdes = 1
		cellValue = 0
		cellPorcen = 0
		celMin = 0
		volMin = 0
	--	logoxt = Bitmap.open("/WIDGETS/imatges/XTminilogo.png")
     	return data
	end	

local function getTelemetryId(name)
    field = getFieldInfo(name)
    if field then
      return field.id
    else
      return -1
    end
end
	
local function background(data)

end

local function refresh(data)

    data.cellID = getTelemetryId("Cels");
    data.cellResult = getValue(data.cellID);
 	--lcd.drawNumber(180,140,totcel*100, DBLSIZE + PREC2 + YELLOW);
	--lcd.drawNumber(180,180,celdes*100, DBLSIZE + PREC2 + YELLOW);
    lcd.drawFilledRectangle(5, 5, 470, 220, SOLID + DARKBLUE , 5, 1);
	lcd.drawNumber(150,10,  totcel*100 , XXLSIZE + PREC2 + YELLOW);
	lcd.drawNumber(150,95,  cellPorcen*100 , XXLSIZE + LEFT + YELLOW);
	lcd.drawText( 225 + 2, 95, " %" , XXLSIZE + YELLOW);
    lcd.drawNumber(305,80,  getValue("Cels-")*100 , XXLSIZE + PREC2 + ORANGE);	
	lcd.drawNumber(340, 150, getValue("Cel--")*100 , LEFT + XXLSIZE + BLINK + PREC2 + ORANGE);
    totcel=0
	-- lcd.drawBitmap(logoxt,430,10); 
	
	if getValue("Cel-") <= 3.50 and getValue("Cel-") > 0 then
	   playTone(500,300,100, PLAY_BACKGROUND);
    end	

  if (type(data.cellResult) == "table") then
    for i, v in ipairs(data.cellResult) do  -- busca los valores de cada celta en la tabla
	    
		totcel = totcel + v  -- suma el valor total de las celdas
		cellValue = v

		
        -- asigna el identificador de celda i el voltaje de la celda menor Cel--		
 		if v <= getValue("Cel--") and v > 0 then
		   celMin = i
		   volMin = v*100
		end

		-- Dibuja los valores de las celdas en pantalla
		if i == 1 then 
		   llarg = 20;
		   lcd.drawText(15, llarg, i , DBLSIZE + YELLOW); 
		   lcd.drawNumber(60, llarg , getValue("Cel1")*100 , DBLSIZE + PREC2 + YELLOW);
		end
		if i == 2 then 
		   llarg = 50;
		   lcd.drawText(15, llarg, i , DBLSIZE + YELLOW);
		   lcd.drawNumber(60, llarg , getValue("Cel2")*100 , DBLSIZE + PREC2 + YELLOW);
		end
		if i == 3 then 
		   llarg = 80;
		   lcd.drawText(15, llarg, i , DBLSIZE + YELLOW);
		   lcd.drawNumber(60, llarg , getValue("Cel3")*100 , DBLSIZE + PREC2 + YELLOW);
		end
		if i == 4 then 
		   llarg = 110;
		   lcd.drawText(15, llarg, i , DBLSIZE + YELLOW);
		   lcd.drawNumber(60, llarg , getValue("Cel4")*100 , DBLSIZE + PREC2 + YELLOW);
		end
		if i == 5 then 
		   llarg = 140;
		   lcd.drawText(15, llarg, i , DBLSIZE + YELLOW);
		   lcd.drawNumber(60, llarg , getValue("Cel5")*100 , DBLSIZE + PREC2 + YELLOW);
		end		
		if i == 6 then 
		   llarg = 170;	
		   lcd.drawText(15, llarg, i , DBLSIZE + YELLOW);
		   lcd.drawNumber(60, llarg , getValue("Cel6")*100 , DBLSIZE + PREC2 + YELLOW);
		end		
	    celdes =  i * 4.2  ;
		cellPorcen = (totcel-(i*3.6))/(celdes-(i*3.6));
		if cellPorcen <= 0 then
		   cellPorcen =0;
		end


    end


 end
end

return{ name="totcel",options=options, create=create, update=update, refresh=refresh, background=background }
--------------------------------------------------------------------------
-- Lua widget to view RSSI signal during flight						     --
-- 				                                                         --
--                                                                       --
-- Author:  Xavier Torradas                                              --
-- Date:    2022-03-01                                                   --
-- Version: 1.0                                                          --
--                                                                       --
-- Free use                                                              --
--                                                                       --
-- 														                 --
--                                                                       --
-- This program is free software; you can redistribute it and/or modify  --
-- it under your responsability.										 --
--                                                                       --
-- This program is distributed in the hope that it will be useful        --
-- but WITHOUT ANY WARRANTY; without even the implied warranty of        --
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  		         --
-- 												                         --
-- The call to getValue() returns frsky GPS and AIRSPEED sensor.		 --
-- This example demonstrates getting GROUND SPEED  from GPS sensor  	 --
-- with value from GSpd when discover new sensors 						 --
-- Also with ASpd sensor if avaible										 --
-- At bottom appears Maxium GSpd and Maxium ASpd blinking in white       --
---------------------------------------------------------------------------

	local options = {}

	local function create(zone, options)
		local data = { zone=zone, options=options, 	}
		   field = 0
		   cellId = -1
		   logoxt = Bitmap.open("/WIDGETS/imatges/XTminilogo.png")
		return data
		
	end

    local function getTelemetryId(name)
       field = getFieldInfo(name)
       if field then
         return field.id
       else
         return -1
       end
    end

	local function update(data, options)
		data.options = options
	end

	local function background(data)

	end 

	local function refresh(data)
	
	-- Determina si existen los sensores
 lcd.drawFilledRectangle(5, 5, 470, 220, SOLID + DARKBLUE , 5, 1); 
 cellId = getTelemetryId("GSpd")
 if cellId > -1 then 
  
      if model.getSensor(4) then
         llarg1 = getValue("GSpd")
      else
         llarg1 = 1
      end

	 -- Sensor GPS velocitat
	   lcd.drawText(data.zone.x + 10, data.zone.y , "GSpd", LEFT + XXLSIZE + WHITE);
	   lcd.drawNumber(data.zone.x + 360, data.zone.y, getValue("GSpd") , LEFT + XXLSIZE + WHITE );
	   lcd.drawText(data.zone.x + 10, data.zone.y + 180 , "GSpd+: ", LEFT + DBLSIZE + WHITE);
	   lcd.drawNumber(data.zone.x + 115, data.zone.y + 180,  getValue("GSpd+"), LEFT + DBLSIZE + BLINK + WHITE );		

 end		
 
 cellId = getTelemetryId("ASpd")
 if cellId > -1 then 
	  if model.getSensor(10) then
         llarg2 = getValue("ASpd")
      else
         llarg2 = 1
      end	
				
	-- valor Airspeed ASpd
	    lcd.drawText(data.zone.x + 10, data.zone.y + 80 , "V.Aire", LEFT + XXLSIZE + YELLOW);
	    lcd.drawNumber(data.zone.x+360, data.zone.y + 80, getValue("ASpd"), LEFT + XXLSIZE + YELLOW );	   
		lcd.drawText(data.zone.x + 300, data.zone.y + 180, "ASpd+ : ", LEFT + DBLSIZE + YELLOW);
		lcd.drawNumber(data.zone.x + 410, data.zone.y + 180, getValue("ASpd+") , LEFT + DBLSIZE + BLINK  + WHITE );
		
 end		
			
		-- lcd.drawBitmap(logoxt,430,30)			
	end


	return { name="GSpd/ASpd", options=options, create=create, update=update, refresh=refresh, background=background }